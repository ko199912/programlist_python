# coding: utf-8

import glob, os, time
from time import sleep


input_path = r'.\SYSLOG_OK\*.LOG'
output_file = r'.\error_logs.txt'
list_Apple = []
num = 0
SYSLOG_num = 0

for filename in glob.glob(input_path):
	GET_SYSLOG_log = filename
	split_SYSLOG_name = GET_SYSLOG_log.split('\\')
	GET_SYSLOG_name = split_SYSLOG_name.pop()
	Format_SYSLOG_name = '//' + GET_SYSLOG_name[0:]
	print(Format_SYSLOG_name)
	list_Apple += [Format_SYSLOG_name]
	SYSLOG_num += 1
	with open(os.path.join(os.getcwd(), filename), mode='r', encoding='utf-8') as f:
		lines = f.readlines()
		lines_strip = [line.strip() for line in lines ]
		# list_Apple += [line_s for line_s in lines_strip if 'Invalid operation' in line_s or 'Last reset cause: ' in line_s or 'Watchdog' in line_s or 'RECOVERY_RESET_IND' in line_s or 'RECOVERY' in line_s or 'fatality' in line_s or 'Exception' in line_s or 'CATEGORY: SW_FAILURE' in line_s or 'Error Handler exception report' in line_s or ' NOTOK' in line_s or 'recovery action' in line_s or 'RadioResetScenario' in line_s or 'cause: sivt update limit reached ' in line_s or 'CellcSibMgmtLteSystemInfoValueTag' in line_s or 'RP3 link 3 LCV error' in line_s] 
		list_Apple += [line_s for line_s in lines_strip if 'EnDssSetupFail' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if 'EnDssKeepAlive timeout' in line_s]

		#list_Apple += [line_s for line_s in lines_strip if 'CRC error received (link: RP3-01 0' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if '</failureReason></' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if '[Detector 6450' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if 'RESET, Detected most recent reset ' in line_s]
########Callが確立されていることを確認するとき############
#		list_Apple += [line_s for line_s in lines_strip if 'msg3' in line_s or 'msg2' in line_s or 'preamble' in line_s]
########GPS###################
#		list_Apple += [line_s for line_s in lines_strip if 'GNSSI' in line_s and ' ' in line_s]
########Cell周り#########
#		list_Apple += [line_s for line_s in lines_strip if 'phase_error: ' in line_s]
#		list_Apple += [line_s for line_s in lines_strip if 'CellController' in line_s]
#		list_Apple += [line_s for line_s in lines_strip if 'CommonBcnNotSet' in line_s]
#		list_Apple += [line_s for line_s in lines_strip if 'Cannot fetch LNCEL_R related' in line_s]
########謎##############
#		list_Apple += [line_s for line_s in lines_strip if 'FamilyObjectsBcnFaultsHandler' in line_s]
#		list_Apple += [line_s for line_s in lines_strip if '19:15:05.491' in line_s and 'Creating shared memory' in line_s]
########ネガティブなワードだけど検索対象広すぎるから確認するときは関係ないところをフィルターして探すこと#########
		# list_Apple += [line_s for line_s in lines_strip if 'cannot' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if 'crash' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if 'rejected' in line_s]
		# list_Apple += [line_s for line_s in lines_strip if '_RESET_' in line_s]
	f.close()

count_sum = len(list_Apple ) - 1
NG_count_sum = 0

# output file
with open(output_file, 'w', encoding='shift-jis') as result_f:
	while num <= count_sum:
		if '<?xml version="1.0" encoding="utf-8"?><soapenv:Envelope xmlns:soapenv=' in list_Apple[num]:
			num += 1
			NG_count_sum += 1
		elif "DBG/COMMON/PmCounterUpdater.cpp:57 Update counter," in list_Apple[num]:
			num += 1
			NG_count_sum += 1
		elif " DBG/cp_rt/UeContextScope.cpp:" in list_Apple[num]:
			num += 1
			NG_count_sum += 1
		elif "[ArrAggrCounterCollectionService:] [updateUri] begin HOME_CELL_NR" in list_Apple[num]:
			num += 1
			NG_count_sum += 1
		else:
			result_f.write(list_Apple[num]+'\n')
			num += 1
#		result_f.write(list_Apple[num]+'\n')
#		num += 1
result_f.close()

print('Completed.detected error log is ' + str(num - SYSLOG_num - NG_count_sum) + '. after 5 second, close Command Prompt')
time.sleep(5)
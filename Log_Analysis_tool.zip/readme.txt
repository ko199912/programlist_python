# OverView:
# "log_analysis.py" is an error log seach tool. You can get error log with ease.

# Setup step(option):
# Step1. If you want to add Seach keywords, please open "log_analysis.py" file from text editer and read the 22 line.
# ※Default keywords is 
# 'NodeState: Failed', 'reportAlarmNotif', 'Invalid operation', 'Detector ', 'fatal'

# Execution Step:
# Step1. Insert target syslog in "SYSLOG" Folder.
# Step1. Duble Click "log_analysis.py".
# Step2. After cmd open automatically, please wait for cmd to close automatically.
# Step3. Open "error_log.txt" file. (if the output file does not exist, please execute it again and check error message on cmd.)
# Step4. You can check the result.
# Step5. Clean up the syslog File in "SYSLOG" Folder.